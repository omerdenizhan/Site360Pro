<?php

if ($_SERVER['REQUEST_URI'] == '/Site360Pro' || $_SERVER['REQUEST_URI'] == '/Site360Pro/') {
    header('Location: http://127.0.0.1:8000/Site360Pro/public');
    exit;
}
